
import "./css/style.css"
import "./js/generateQuestions"
import "./js/script"

//Importing the files

if (module.hot) {
  module.hot.accept();
}

console.log('DOM Loaded');
